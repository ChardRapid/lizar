package com.lizar.web.loader;

import java.io.File;

public class ConfigFile {
	public File file;
	public long last_modify;
}
