package com.lizar.web.loader;

abstract public class Module implements Cell {
	
	public abstract void init_component()throws Exception;

}
