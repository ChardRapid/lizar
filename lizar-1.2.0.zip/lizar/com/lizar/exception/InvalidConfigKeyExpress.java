package com.lizar.exception;

public class InvalidConfigKeyExpress extends RuntimeException{
	private static final long serialVersionUID = -7780149164665729686L;

	public InvalidConfigKeyExpress(String msg) {
		super(msg);
	}

}
