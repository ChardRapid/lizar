package com.lizar.exception;

public class EventHandlingPathIsNotSupported extends RuntimeException{
	
	private static final long serialVersionUID = -7780149164665729686L;

	public EventHandlingPathIsNotSupported(String msg) {
		super(msg);
	}

	
}
